let container=document.querySelector(".container")

let inp=document.getElementById("inp1")
let newWindow=document.querySelector(".mas1")
let icon=document.querySelector("#i1")


let paragraph2=document.querySelector("#p2")
let paragraph3=document.querySelector("#p3")
let paragraph4=document.querySelector("#p4")
let paragraph5=document.querySelector("#p5")
let paragraph6=document.querySelector("#p6")
let paragraph7=document.querySelector("#p7")

inp.addEventListener("click", function(inp) {
    newWindow.style.display="inline"
    icon.style.display="inline"
})

paragraph2.addEventListener("mouseenter", function(int) {
    inp.value=paragraph2.innerText
})
paragraph3.addEventListener("mouseenter", function(int) {
    inp.value=paragraph3.innerText
})
paragraph4.addEventListener("mouseenter", function(int) {
    inp.value=paragraph4.innerText
})
paragraph5.addEventListener("mouseenter", function(int) {
    inp.value=paragraph5.innerText
})
paragraph6.addEventListener("mouseenter", function(int) {
    inp.value=paragraph6.innerText
})
paragraph7.addEventListener("mouseenter", function(int) {
    inp.value=paragraph7.innerText
})